using System;

class Program
{
    static void Main(string[] args)
    { 
		int escolha;
        do
        {
            Console.WriteLine("Tabuada 2021:");
            int ntab;
            int contador = 0;
            Console.Write("Digite qual número da tabuada deseja: ");
            ntab = int.Parse(Console.ReadLine());
            for (contador = 0; contador <= 10; contador++)
            {
                Console.WriteLine("{0} x {1} = {2}", ntab, contador, ntab * contador);
            }
            Console.WriteLine("1 - Novo calculo");
            Console.WriteLine("2 - Sair");
            Console.WriteLine("Digite a opção desejada: ");
            escolha = int.Parse(Console.ReadLine());
			Console.Clear();
        } while (escolha != 2);
    }
}