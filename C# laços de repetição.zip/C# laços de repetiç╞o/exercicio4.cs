using System;

class Program
{
    static void Main(string[] args)
    {
    int n=1, maior = 0;

while (n != 0)
{
	Console.Write("Digite um número: ");
	n=int.Parse(Console.ReadLine());
	if (n > maior)
	{
		maior = n;
	}
}
Console.Write("O maior número foi: "+maior);
Console.ReadKey();
    }
}