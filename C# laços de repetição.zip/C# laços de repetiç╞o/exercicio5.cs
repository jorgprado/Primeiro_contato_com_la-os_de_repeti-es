using System;

class Program
{
    static void Main(string[] args)
    {
        int n, par = 0, impar = 0, positivo = 0, negativo = 0;

do
{
	Console.Write("Digite um número: ");
	n=int.Parse(Console.ReadLine());
	if (n % 2 == 0)
	{
		par++;
	}
	else
	{
		impar++;
	}
	if (n >= 0)
	{
		positivo++;
	}
	else
	{
		negativo++;
	}
}while (n != 0);
Console.WriteLine("Qtd.pares: "+par);
Console.WriteLine("Qtd.ímpares: "+impar);
Console.WriteLine("Qtd.positivos: "+positivo);
Console.WriteLine("Qtd.negativos: "+negativo);
Console.ReadKey();
    }
}