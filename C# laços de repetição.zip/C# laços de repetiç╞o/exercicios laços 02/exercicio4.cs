/*Exercício 4: Escreva um programa que exiba na tela a quantidade de números ímpares existentes entre 
dois números que o usuário digitar (testar inclusive os números digitados).*/
 
using System;
class Program
{
    static void Main(string [] args)
    {
        Console.WriteLine("4) Escreva um programa que exiba na tela a quantidade de números ímpares existentes entre dois números que o usuário digitar (testar inclusive os números digitados).\n");
            Console.Write("Digite um número: ");
            int n1 ,n2 , total=0, y, y1;
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Digite outro número: ");
            n2 = int.Parse(Console.ReadLine());
            if (n1 <= n2){
                y = n1;
                y1 = n2;
            }else{
                y1 = n1;
                y = n2;
            }
            for (int x = y; x <= y1; x++){
                if (x % 2 != 0) 
				{ total++; }
            }
            Console.WriteLine("Quantidade de números ímpares entre {0} e {1} é {2}",y1, y, total);
        }

    }
