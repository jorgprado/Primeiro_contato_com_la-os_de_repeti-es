/*Exercício 1: Escreva um programa que exiba na tela em ordem crescente, apenas os números pares existentes de 11 a 250. */
using System;
class Program
{
    static void Main(string[] args)
    {
        int x, par=0;
        for(x=11;x<=250;x++)
        {
            if (x % 2 == 0)
	        {
		    par++;
            Console.WriteLine("Números par de 11 a 250 {0}", x);
			}
        }
	}
}