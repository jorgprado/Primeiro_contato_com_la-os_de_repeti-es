/*Escreva um programa que calcule e exiba a média de 10 notas digitadas pelo usuário. Considerar notas válidas, 
somente valores entre 0 (zero) e 10 (dez). Se o usuário digitar algum valor inválido, deverá ser exibida uma 
mensagem informando o ocorrido*/

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Média de 10 notas.\n");
        int loop, nota, media=0;

        for (loop = 1; loop <= 10; loop++)
        {
            do
            {
                Console.WriteLine("Digite a {0}ª Nota: ",loop);
                nota = int.Parse(Console.ReadLine());
                if (nota < 0 || nota > 10)
                {
                    Console.WriteLine("Valor não valido");
                }
            } while (nota < 0 || nota > 10);
            media +=  nota;
        }
        Console.WriteLine("\n\nMédia final do aluno é: " + m / 10);
    }
}
