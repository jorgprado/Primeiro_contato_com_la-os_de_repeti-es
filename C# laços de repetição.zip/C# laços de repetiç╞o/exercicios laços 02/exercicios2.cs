: /*Escreva um programa que exiba na tela em ordem decrescente,
 apenas os números ímpares existentes entre dois números digitados pelo usuário (inclusive eles).*/

using System;

class Program
{
    static void Main(string[] args)
    { 
	int a, b, x, y;
	Console.WriteLine("digite um valor: ");
	x = int.Parse(Console.ReadLine());
	Console.WriteLine("Digite outro valor: ");
	y = int.Parse(Console.ReadLine());
	if (x >= y)
	{
		a=x;
	}
	else{
		a=y;
	}
	if (x <= y)
	{
		b=x;
	}
	else{
		b=y;
	}
	Console.WriteLine();
		for(int i = a; i > b; i--)
		{
			if (i % 2 != 0)
			{
				Console.WriteLine(+i);
			}
		}
    }
}