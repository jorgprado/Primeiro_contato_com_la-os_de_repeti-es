/*7: Escreva um programa que exiba todos os números de 1 a 100 e a cada número que for múltiplo
 de 10, exiba a mensagem “MÚLTIPLO DE 10”.*/


using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Contador de 1 a 100");
        Console.WriteLine("Aperte uma tecla para começar");
        Console.ReadKey();
        int loop;
        for (loop = 1; loop <= 100; loop++)
        {
            Console.Write("\n\n"+loop);
            if (loop % 10 == 0)
            {
                Console.Write("  MÚLTIPLO DE 10");
            } 
        }
    }
}




