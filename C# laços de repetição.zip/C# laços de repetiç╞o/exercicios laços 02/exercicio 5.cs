/*Escreva um programa que leia 15 números inteiros e exiba na tela ao final, o maior número que foi digitado pelo usuário.*/
using System;

class Program {
    static void Main(string[] args) {
            Console.WriteLine("Maior numero da sequencia");
            
			int numA, nG;
		
            Console.Write("Digite o 1° número: ");
            nG = int.Parse(Console.ReadLine());
            
			for (int x = 1; x < 15; x++){
                Console.Write("Digite o {0}° número: ",x+1);
                numA = int.Parse(Console.ReadLine());
                if (numA > nG){
                    nG = numA;
                }
            }
            Console.WriteLine("\nO maior número digitado foi: {0}", nG);
    }
}