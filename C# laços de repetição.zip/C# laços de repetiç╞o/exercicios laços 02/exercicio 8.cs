/*8: Escreva um programa que calcule o fatorial de um número informado pelo usuário. 
Dica: O fatorial de um número N é dado pela fórmula: N! = 1 * 2 * 3 * 4 * 5 * ... * N*/

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Fatorial do número");
        double res = 1;
        int num;
        Console.Write("Digite um Número: ");
        num = int.Parse(Console.ReadLine());
        while (num != 1)
        {
            res = res * num;
            num = num - 1;
        }
        Console.WriteLine("\nO fatorial do número escolhido é "+res);
    }
}

