/*10: Faça um programa que leia as variáveis C e N, respectivamente código e número de horas trabalhadas de um
 operário. Calcule o salário sabendo-se que ele ganha R$ 10,00 por hora. Quando o número de horas exceder a 50,
  calcule o excesso de pagamento armazenando-o na variável E, caso contrário zerar tal variável. A hora excedente de
   trabalho vale R$ 20,00. No final do processamento imprimir o salário total e o salário excedente. O programa só deve
    parar de rodar quando o usuário responder "S" na seguinte pergunta, "Deseja encerrar o programa?".*/

using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("\nSalário Total e excedente");
        int s, hour, aux, sal, hex;
        do
        {
            Console.Write("\n\nDigite o número de horas trabalhadas: ");
            hour = int.Parse(Console.ReadLine());
            if (hour > 50)
            {
                aux = hour - 50;
                hex = aux * 20;
                sal = 50 * 10;
                Console.WriteLine("Salário total {0}\n\nSalário Excedente {1}", sal, hex);
            }
            else
            {
                aux = 0;
                sal = hour * 10;
                Console.WriteLine("Salário total {0}\n\nSalário Excedente {1}", sal, aux);
            }
            Console.WriteLine("\n\nDeseja continuar ? (1)Sim (2)Não");
            s = int.Parse(Console.ReadLine());
        } while(s != 2);
    }
}