/*9: Escreva um programa que leia vários números inteiros e ao final informe quantos números pares,
 quantos números ímpares, quantos números positivos e quantos números negativos foram digitados
  pelo usuário. O programa só deve parar de rodar quando o usuário responder "S" na seguinte pergunta,
   "Deseja encerrar o programa?".*/

using System;

class Program
{
    static void Main(string[] args)
    {
        int num = 1, positivo = 0, impar = 0, positivo1 = 0, num1 = 0, x;//declaração de variaveis

        Console.WriteLine("Par Impar Positivo Negativo");//Titulo
        do//Iniciação do Loop
        {
            Console.WriteLine("\nDigite um valor:");
            num = int.Parse(Console.ReadLine());//Aplicação do valor na variavel n
            if (num % 2 == 0)//Se o resto da divisão do valor de n for igual a 0 o número é par
            {
                positivo++;
            }
            else//Caso contrário é impar
            {
                impar++;
            }
            if (num >= 0)//Se o valor de n for maior ou igual a 0 o número é positivo
            {
                positivo1++;
            }
            else//Caso contrário é negativo
            {
                num1++;
            }
            Console.WriteLine("Deseja continuar ? (1)Sim (2)Não");
            x = int.Parse(Console.ReadLine());
        } while (x!=2); //Fim do Loop

        //Mostrar o resutado para o usuário
        Console.WriteLine("\n\nQtd.Pares: " + positivo);
        Console.WriteLine("\n\nQtd.Impares: " + impar);
        Console.WriteLine("\n\nQtd.Positivos: " + positivo1);
        Console.WriteLine("\n\nQtd.Negativos: " + num1);
        Console.ReadKey();
    }
}