using System;

class Program
{
    static void Main(string[] args)
    {
int c;
for (c=1;c<=10;c++)
{
	Console.WriteLine("4 x {0} = {1}", c, 4*c);
}
Console.ReadKey();
    }
}