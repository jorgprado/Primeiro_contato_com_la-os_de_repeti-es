using System;

class Program
{
    static void Main(string[] args)
    {
double n, soma=0;
int x;
for (x=1;x<=15;x++)
{
	Console.Write("Digite um número: ");
	n=double.Parse(Console.ReadLine());
	soma+=n;   // soma+=n é o mesmo que soma=soma+n
}
Console.Write("A média é: "+(soma/15));

Console.ReadKey();
    }
}